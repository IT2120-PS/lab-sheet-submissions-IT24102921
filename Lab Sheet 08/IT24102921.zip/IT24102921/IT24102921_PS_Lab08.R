setwd("C:\\Users\\Acer\\Desktop\\IT24102921")
getwd

data <- read.table("Exercise - LaptopsWeights.txt", header = TRUE)
laptop_weights <- data$Weight.kg.
n_population <- length(laptop_weights)
popmn <- mean(laptop_weights)
popsd <- sd(laptop_weights) * sqrt((n_population -1)/ n_population)

print(paste("Population Mean: ", popmn))
print(paste("Population Standard Deviation: ", popsd))

#2

samples <- c()
number_of_samples <- 25
sample_size <- 6

for (i in 1:number_of_samples) {
  s <- sample(laptop_weights, sample_size,replace = TRUE)
  samples <- cbind(samples,s)
}
colnames(samples) <- paste("Sample",1:number_of_samples)

samplemn <- apply(samples, 2,mean)
samplesd <- apply(samples,2,sd)

print(samplemn)
print(samplesd)

#3

mean_of_sample_means <- mean(samplemn)
sd_of_sample_mean <- sd(samplemn)

print(paste("Mean of the 25 sample means:", mean_of_sample_means))
print(paste("Standard Deviation of 25 sample means:", sd_of_sample_mean))

theoretical_standard_error <- popsd/sqrt(sample_size)

print(paste("Population Mean:",popmn))
print(paste("Theoretical_Standard_Error:",theoretical_standard_error))


















