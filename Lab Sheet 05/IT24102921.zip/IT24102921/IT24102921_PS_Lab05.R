setwd("C:\\Users\\IT24102921\\Desktop\\IT24102921")
getwd()

Delivery_Times<-read.table("Exercise - Lab 05.txt",header=TRUE)
head(Delivery_Times)
attach(Delivery_Times)

histogram<- hist(Delivery_Time_.minutes.,main = "Delivery Time(Minutes)",breaks=seq(20,70, length=10),right=TRUE)

#The curve shows a bimodal distribution and appears approximately symmetrical. The data spans between 20 to 70 minutes.

freq_table<-hist(Delivery_Time_.minutes.,breaks=breaks,)
cum_freq<-cumsum(freq_table$counts)

plot(freq_table$mids,cum_freq,type="o",main="cumulative Frequency Polygon",xlab="Delivery Time", ylab="Cumulative Frequency")